angular.module('starter', ['ionic', 'starter.controllers', 'ngTagsInput', 'ngCordova'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})




.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
  

 .state('app', {
      url: '/app',
	   abstract: true,
        templateUrl: 'templates/menu.html',
		controller:'AppCtrl'
	
  })
  
	  .state('app.recent', {
    url: '/recent',
    views: {
      'menuContent' :{
        templateUrl: 'templates/recent.html',
		controller:'RecentCtrl'
      }
    }
  })
  
 
  
  
	  .state('app.save', {
    url: '/save',
    views: {
      'menuContent' :{
        templateUrl: 'templates/save.html',
		controller:'SaveCtrl'
		
      }
    }
  })
  
  
  
	  .state('app.profile', {
    url: '/profile',
    views: {
      'menuContent' :{
        templateUrl: 'templates/profile.html',
		controller:'RecentCtrl'
		
      }
    }
  })
  
  
   .state('app.blox', {
    url: '/blox',
    views: {
      'menuContent' :{
        templateUrl: 'templates/blox.html',
		controller:'BloxCtrl'
      }
    }
  })
  
  
   .state('app.application', {
    url: '/application',
    views: {
      'menuContent' :{
        templateUrl: 'templates/application.html',
		controller:'RecentCtrl'
		
      }
    }
  })
/*  
 .state('app.offline-files', {
    url: '/offline-files',
    views: {
      'menuContent' :{
        templateUrl: 'templates/offline-files.html',
      }
    }
  })
*/  
  
   .state('app.notification', {
    url: '/notification',
    views: {
      'menuContent' :{
        templateUrl: 'templates/notification.html',
		
      }
    }
  })
  
	
 .state('login', {
      url: '/login',
	   	//abstract: true,
        templateUrl: 'templates/login.html',
		controller:'SignInCtrl'
	
  })
  

   .state('app.share', {
    url: '/share',
    views: {
      'menuContent' :{
        templateUrl: 'templates/share.html',
      }
    }
  })
  
  
   .state('app.member', {
    url: '/member',
    views: {
      'menuContent' :{
        templateUrl: 'templates/member.html',
      }
    }
  })
  
  
  .state('search', {
    url: '/search',
        templateUrl: 'templates/search.html',
		
	
  })
  
  
 
.state('signup', {
	url: '/signup',
  templateUrl: 'templates/signup.html',
  controller:'SignInCtrl'
});
	

  
  $urlRouterProvider.otherwise('/login');
})


 
 
  .controller('SignInCtrl', function($scope, $state) {
  
  $scope.aaa = function(user) {
    console.log('menu-In');
    $state.go('app.recent');
  }
})	


  .controller('AppCtrl', function($scope, $state,$ionicHistory) {
            $scope.myGoBack = function(back) {
				console.log('Back-In');
                $ionicHistory.goBack();
				
            };
			
			
	 $scope.doRefresh = function() {
		PersonService.GetNewUser().then(function(items){
			$scope.items = items.concat($scope.items);
			
			//Stop the ion-refresher from spinning
			$scope.$broadcast('scroll.refreshComplete');
		});
  };

   })
   
 
  .controller('SaveCtrl', function($scope, $ionicActionSheet, $cordovaCamera,  $cordovaInAppBrowser) {

  $scope.showActionsheet = function() {
    
    $ionicActionSheet.show({
      titleText: 'Add to Blox',
      buttons: [
        { text: '<i class="icon ion-image"></i> Upload photos or videos' },
        { text: '<i class="icon ion-upload"></i> Upload files' },
		    { text: '<i class="icon ion-document-text"></i> Create a new text file' },
			  { text: '<i class="icon ion-camera"></i> Take a photo' },
		
      ],
    
			  buttonClicked: function(index, $ionicPopup) {
            console.log('BUTTON CLICKED', index);
			  if(index === 0){$scope.choosePhoto();}
			  else if(index === 3){$scope.takePhoto();}
             <!--else {$scope.takePhoto();}-->
			 return true;
			
			  },
			  
      destructiveButtonClicked: function() {
        console.log('DESTRUCT');
        return true;
      }
    });
  }; 
    
	
	
	
	  $scope.takePhoto = function () {
                  var options = {
                    quality: 75,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.CAMERA,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 300,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
   
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
                }
                
       $scope.choosePhoto = function () {
                  var options = {
                    quality: 75,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 300,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
   
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
                }
				
				 $scope.openBrowser = function() {
			cordova.ThemeableBrowser.open('https://goal.com', '_self', {
	statusbar: {
        color: '#ffffffff'
    },
    toolbar: {
        height: 60,
        color: '#c63325'
    },
    title: {
        color: '#ffffff',
        showPageTitle: true
    },
   backButton: {
        image: 'back',
        imagePressed: 'back_pressed',
        align: 'left',
        event: 'backPressed'
		
    },
    forwardButton: {
        image: 'forward',
        imagePressed: 'forward_pressed',
        align: 'left',
        event: 'forwardPressed'
    },
    closeButton: {
        image: 'close',
        imagePressed: 'close_pressed',
        align: 'right',
        event: 'closePressed'
    },
    
   backButtonCanClose: true
}).addEventListener(cordova.ThemeableBrowser.EVT_ERR, function(e) {
    console.error(e.message);
}).addEventListener(cordova.ThemeableBrowser.EVT_WRN, function(e) {
    console.log(e.message);
});
 
				 };
 })
 


 
  .controller('BloxCtrl', function($scope, $ionicPopup, $state, $ionicPopover, $ionicListDelegate, $ionicActionSheet, $ionicHistory) {
	  
	 $scope.aaa = function() {
      $scope.data = {}
    
      // Custom popup
      var myPopup = $ionicPopup.show({
         template: '<input type = "text" ng-model = "data.model" placeholder="Enter folder name">',
         title: 'Folder name',
         subTitle: '',
         scope: $scope,
			
         buttons: [
            { text: 'Cancel' }, {
               text: '<b>Create</b>',
              
                  onTap: function(e) {
						
                     if (!$scope.data.model) {
                        //don't allow the user to close unless he enters model...
                           e.preventDefault();
                     } else {
						  $state.go('app.save');
                        return $scope.data.model;
                     }
                  }
            }
         ]
      });

    myPopup.then(function(res) {
         console.log('Tapped!', res);
		
  
      }); 

 };
 
 
 $ionicPopover.fromTemplateUrl('templates/popover.html', {
    scope: $scope,
  }).then(function(popover) {
    $scope.popover = popover;
  });
  
  
  
 
  
   $scope.show1 = false;
  
  $scope.click1 = function($event) { 
    $event.stopPropagation();
    $scope.show1 = !$scope.show1;
   
    $ionicListDelegate.closeOptionButtons(); }
  $scope.hide = function() { 
  
    $scope.show1 = false;
    $ionicListDelegate.closeOptionButtons(); }
	

	/* list checkbox*/
	
	  $scope.deList = [ { checked: false } ];
  
	  $scope.deeList = [{ checked: false } ];
  
	  $scope.deeeList = [{ checked: false } ];
	  
	  
	  
	  $scope.showActionsheet = function() {
    
    $ionicActionSheet.show({
     
      buttons: [
        { text: '<i class="icon ion-folder"></i> <b>Folder-blox1'},
        { text: '<i class="icon ion-person-add"></i> Share' },
		    { text: '<i class="icon ion-edit"></i> Rename' },
			  { text: '<i class="icon ion-trash-b"></i> Delete'},
		
      ],
      
      
		  
			  buttonClicked: function(index, $ionicPopup) {
            console.log('BUTTON CLICKED', index);
			if(index === 1){$state.go('app.share');}
             else if(index === 2){$scope.showPrompt();}
			 return true;
			
			  },
           
         
		  
		  

      destructiveButtonClicked: function() {
        console.log('DESTRUCT');
        return true;
      }
    });
  }; 
  
	
  $scope.showPrompt = function() {
        var myPopup = $ionicPopup.show({
        template: '<input type = "text" ng-model = "data.rename" placeholder="Enter folder name">',
         title: 'Rename Folder',
        scope: $scope,
         buttons: [
            { text: 'Cancel' }, {
               text: '<b>Rename</b>',
			   
           <!-- type: 'button-positive',-->
            onTap: function(e) {
              if (!$scope.data.model) {
                //don't allow the user to close unless he enters wifi password
                e.preventDefault();
              } else {
						  $state.go('app.save');
						   return $scope.data.rename;
              }
            }
          },
        ]
      });
    };
	
	$scope.page =function(){
	 myPopup.then(function() {
         console.log('Tapped!');
		   $state.go('app.share');
		 
	 });
	 }




 
  })
	  

 .controller('RecentCtrl', function($scope, $ionicPopup, $state, $ionicPopover, $ionicListDelegate, $ionicActionSheet, $cordovaCamera, $cordovaInAppBrowser) {

   // When button is clicked, the popup will be shown...
   $scope.showPopup = function() {
      $scope.data = {}
    
      // Custom popup
      var myPopup = $ionicPopup.show({
         template: '<input type = "text" ng-model = "data.model" placeholder="Enter folder name">',
         title: 'Create Folder',
         subTitle: '',
         scope: $scope,
			
         buttons: [
            { text: 'Cancel' }, {
               text: '<b>Save</b>',
              
                  onTap: function(e) {
						
                     if (!$scope.data.model) {
						  
                        //don't allow the user to close unless he enters model...
                           e.preventDefault();
						   
                     }  else {
						  $state.go('app.save');
						   return $scope.data.model;
						}
                  }
            }
         ]
      });


  
    myPopup.then(function() {
         console.log('Tapped!');
		
      }); 
	  
	   

 };





  $ionicPopover.fromTemplateUrl('templates/popover.html', {
    scope: $scope,
  }).then(function(popover) {
    $scope.popover = popover;
  });
  
  
  

  /*show  and  hide function for che*/
  $scope.show1 = false;
  
  $scope.click1 = function($event) { 
    $event.stopPropagation();
    $scope.show1 = !$scope.show1;
   
    $ionicListDelegate.closeOptionButtons(); }
  $scope.hide = function() { 
  
    $scope.show1 = false;
    $ionicListDelegate.closeOptionButtons(); }
	

	/* list checkbox*/
	
	  $scope.devList = [ { checked: false } ];
  
	  $scope.devvList = [{ checked: false } ];
  
	  $scope.devvvList = [{ checked: false } ];
	  
	  
	 
	  /* actionsheet for recent */
 $scope.showActionsheet = function() {
    
    $ionicActionSheet.show({
     
      buttons: [
        { text: '<i class="icon ion-folder"></i> <b>Folder-blox1'},
        { text: '<i class="icon ion-person-add"></i> Share' },
		    { text: '<i class="icon ion-edit"></i> Rename' },
			  { text: '<i class="icon ion-trash-b"></i> Delete'},
		
      ],

	  /*onclick rename button popup open */ 

			  buttonClicked: function(index, $ionicPopup) {
            console.log('BUTTON CLICKED', index);
			if(index === 1){$state.go('app.share');}
             else if(index === 2){$scope.showPrompt();}
			 return true;
			
			  },
           
         

      destructiveButtonClicked: function() {
        console.log('DESTRUCT');
        return true;
      }
    });
  }; 


  $scope.showPrompt = function() {
        var myPopup = $ionicPopup.show({
        template: '<input type = "text" ng-model = "data.rename" placeholder="Enter folder name">',
         title: 'Rename Folder',
        scope: $scope,
         buttons: [
            { text: 'Cancel' }, {
               text: '<b>Rename</b>',
			   
           <!-- type: 'button-positive',-->
            onTap: function(e) {
              if (!$scope.data.rename) {
                //don't allow the user to close unless he enters wifi password
                e.preventDefault();
              } else {
						  $state.go('app.save');
						   return $scope.data.rename;
              }
            }
          },
        ]
      });
    };

/* profile actionsheet open on click */

$scope.showActionsheetprof = function() {
   $ionicActionSheet.show({
      titleText: 'Update account photo',
      buttons: [
        <!--{ text: '<i class="icon ion-image"></i> Choose from Blox'},-->
		    { text: '<i class="icon ion-images"></i> Choose from gallery' },
			  { text: '<i class="icon ion-camera"></i> Use camera'},
		
      ],
      
      buttonClicked: function(index, $ionicPopup) {
            console.log('BUTTON CLICKED', index);
			  if(index === 0){$scope.choosePhoto();}
			  else if(index === 1){$scope.takePhoto();}
             <!--else {$scope.takePhoto();}-->
			 return true;
			
			  },
      destructiveButtonClicked: function() {
        console.log('DESTRUCT');
        return true;
      }
    });
  }; 
   $scope.takePhoto = function () {
                  var options = {
                    quality: 75,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.CAMERA,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 300,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
   
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
                }
                
       $scope.choosePhoto = function () {
                  var options = {
                    quality: 75,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 300,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
   
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
                }
                



 $scope.openBrowser = function() {
			cordova.ThemeableBrowser.open('https://devprivasera.com/#/login', '_blank', {
	statusbar: {
        color: '#ffffffff'
    },
    toolbar: {
        height: 60,
        color: '#da4436'
    },
    title: {
        color: '#ffffff',
        showPageTitle: true
    },
   backButton: {
        image: 'back',
        imagePressed: 'back_pressed',
        align: 'left',
		padding: 10,
        event: 'backPressed',
		
    },
    forwardButton: {
        image: 'forward',
        imagePressed: 'forward_pressed',
        align: 'left',
		padding: 10,
        event: 'forwardPressed'
    },
    closeButton: {
        image: 'close',
        imagePressed: 'close_pressed',
        align: 'left',
		padding: 10,
        event: 'closePressed'
    },
    
   backButtonCanClose: true
}).addEventListener('backPressed', function(e) {
    alert('back pressed');
}).addEventListener('helloPressed', function(e) {
    alert('hello pressed');
}).addEventListener('sharePressed', function(e) {
    alert(e.url);
}).addEventListener(cordova.ThemeableBrowser.EVT_ERR, function(e) {
    console.error(e.message);
}).addEventListener(cordova.ThemeableBrowser.EVT_WRN, function(e) {
    console.log(e.message);
});
 
				 };
})
 

  
.controller('AppCtrl', function($scope) {
});
